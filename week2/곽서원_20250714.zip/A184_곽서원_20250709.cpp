#include<iostream>
#include<string>
using namespace std;

int main() {

 cout <<"|\\_/|"<< endl;
 cout <<"|q p|   /} "<< endl;
 cout <<"( 0 )\"\"\"\\"<< endl;
 cout <<"|\"^\"`    |"<< endl;
 cout <<"||_/=\\\\__|";
 return 0;
}
