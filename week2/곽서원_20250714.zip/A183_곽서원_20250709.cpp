#include<iostream>
#include<string>
using namespace std;

int main() {

 cout << "\\    \/\\" << endl;
 cout << " \)  \( \'\)" << endl;
 cout << "\(  \/  \) " << endl;
 cout << " \\\(__\)\|";
 return 0;
}