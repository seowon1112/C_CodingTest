#include<iostream>
#include<string>
using namespace std;

int main() {
 int id;
  cin >> id;
  cout << id - 543;
 return 0;
}